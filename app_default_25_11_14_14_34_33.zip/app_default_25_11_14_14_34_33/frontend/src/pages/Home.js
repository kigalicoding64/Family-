import React, { useEffect, useState } from 'react';
import { fetchFamilyInfo } from '../api/api.js';

const Home = () => {
  const [familyInfo, setFamilyInfo] = useState({ name: '', description: '' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadFamilyInfo = async () => {
      try {
        const data = await fetchFamilyInfo();
        setFamilyInfo(data);
      } catch (err) {
        setError('Failed to load family information.');
      } finally {
        setLoading(false);
      }
    };
    loadFamilyInfo();
  }, []);

  if (loading) {
    return <p>Loading family introduction...</p>;
  }

  if (error) {
    return <p role="alert" style={{ color: 'red' }}>{error}</p>;
  }

  return (
    <section
      aria-labelledby="family-intro-title"
      style={{
        maxWidth: '800px',
        margin: '0 auto',
        padding: '1rem',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        lineHeight: 1.6
      }}
    >
      <h1 id="family-intro-title" style={{ fontSize: '2.2rem', color: '#34495e' }}>
        {familyInfo.name || 'Our Family'}
      </h1>
      <p style={{ whiteSpace: 'pre-line', fontSize: '1.1rem', color: '#555' }}>
        {familyInfo.description || 'Welcome to our family website! We cherish our memories and moments together.'}
      </p>
    </section>
  );
};

export default Home;
