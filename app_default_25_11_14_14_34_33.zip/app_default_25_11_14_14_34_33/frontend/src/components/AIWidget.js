import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';

const AIWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [conversations, setConversations] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const containerRef = useRef(null);

  // Close widget if clicked outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const toggleOpen = () => setIsOpen((open) => !open);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { sender: 'user', text: input.trim() };
    setConversations((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // For demonstration, simple echo bot with delay.
      // Replace with real AI backend or third party API integration.
      // Example: call backend /api/ai or external AI API.

      // Simulated AI response (echo reversed text after delay)
      const responseText = await new Promise((resolve) =>
        setTimeout(() => resolve(`You said: "${input.trim()}"`), 1200)
      );

      const aiMessage = { sender: 'ai', text: responseText };
      setConversations((prev) => [...prev, aiMessage]);
    } catch (err) {
      const errorMessage = { sender: 'ai', text: 'Sorry, something went wrong.' };
      setConversations((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      ref={containerRef}
      style={{
        position: 'fixed',
        bottom: 20,
        left: 20,
        width: isOpen ? 320 : 60,
        height: isOpen ? 400 : 60,
        backgroundColor: '#2980b9',
        borderRadius: 12,
        boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
        color: 'white',
        transition: 'width 0.3s ease, height 0.3s ease',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        zIndex: 1100
      }}
      aria-label="AI Assistant Widget"
    >
      <button
        aria-label={isOpen ? 'Close AI assistant' : 'Open AI assistant'}
        onClick={toggleOpen}
        style={{
          backgroundColor: '#1a5276',
          border: 'none',
          color: 'white',
          fontSize: 24,
          cursor: 'pointer',
          padding: '0.5rem',
          borderRadius: '12px 12px 0 0',
          outline: 'none'
        }}
      >
        {isOpen ? '✕' : '💬'}
      </button>

      {isOpen && (
        <>
          <div
            aria-live="polite"
            style={{
              flex: 1,
              overflowY: 'auto',
              padding: '0.5rem',
              fontSize: '0.9rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.5rem'
            }}
          >
            {conversations.length === 0 && (
              <div style={{ fontStyle: 'italic', opacity: 0.7 }}>
                Ask me anything about your family!
              </div>
            )}
            {conversations.map((msg, idx) => (
              <div
                key={idx}
                style={{
                  alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start',
                  backgroundColor: msg.sender === 'user' ? '#3498db' : '#21618c',
                  borderRadius: 12,
                  padding: '0.4rem 0.8rem',
                  maxWidth: '80%',
                  wordBreak: 'break-word',
                  boxShadow: '0 1px 2px rgba(0,0,0,0.2)'
                }}
              >
                {msg.text}
              </div>
            ))}
            {isLoading && (
              <div
                style={{
                  fontStyle: 'italic',
                  opacity: 0.7,
                  alignSelf: 'flex-start'
                }}
              >
                AI is typing...
              </div>
            )}
          </div>

          <form
            onSubmit={handleSubmit}
            style={{
              display: 'flex',
              gap: '0.5rem',
              padding: '0.5rem',
              borderTop: '1px solid rgba(255,255,255,0.3)'
            }}
          >
            <input
              type="text"
              aria-label="Type your message"
              placeholder="Say something..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={isLoading}
              style={{
                flexGrow: 1,
                borderRadius: 12,
                border: 'none',
                padding: '0.5rem',
                fontSize: '1rem',
                outline: 'none'
              }}
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              style={{
                backgroundColor: '#1a5276',
                border: 'none',
                color: 'white',
                fontWeight: 'bold',
                fontSize: '1.2rem',
                cursor: isLoading || !input.trim() ? 'not-allowed' : 'pointer',
                borderRadius: 12,
                padding: '0 1rem'
              }}
            >
              ➤
            </button>
          </form>
        </>
      )}
    </div>
  );
};

export default AIWidget;
