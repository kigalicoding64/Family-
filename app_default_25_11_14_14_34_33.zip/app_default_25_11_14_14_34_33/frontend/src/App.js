import React from 'react';
import { Routes, Route } from 'react-router-dom';
import NavigationBar from './components/NavigationBar.js';
import AIWidget from './components/AIWidget.js';
import Home from './pages/Home.js';
import Gallery from './pages/Gallery.js';
import Events from './pages/Events.js';
import Contact from './pages/Contact.js';

function App() {
  return (
    <>
      <NavigationBar />
      <main style={{ padding: '1rem', minHeight: '80vh' }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/events" element={<Events />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<h2>404 - Page Not Found</h2>} />
        </Routes>
      </main>
      <AIWidget />
    </>
  );
}

export default App;
