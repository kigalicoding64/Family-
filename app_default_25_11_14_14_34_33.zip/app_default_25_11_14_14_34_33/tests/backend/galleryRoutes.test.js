import request from 'supertest';
import mongoose from 'mongoose';
import express from 'express';
import galleryRoutes from '../../backend/routes/galleryRoutes.js';
import GalleryPhoto from '../../backend/models/GalleryPhoto.js';

const app = express();
app.use(express.json());
app.use('/api/gallery', galleryRoutes);

beforeAll(async () => {
  const mongoUri = 'mongodb://127.0.0.1/familywebsite_test_gallery';
  await mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });
  await GalleryPhoto.deleteMany({});
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('GET /api/gallery', () => {
  it('should return empty array when no photos', async () => {
    const res = await request(app).get('/api/gallery');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBe(0);
  });

  it('should return photos if exist', async () => {
    const photo = new GalleryPhoto({
      url: 'https://picsum.photos/200/300.jpg',
      description: 'Test photo'
    });
    await photo.save();

    const res = await request(app).get('/api/gallery');
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
    expect(res.body[0].description).toBe('Test photo');
  });
});

describe('POST /api/gallery', () => {
  it('should add a new photo with valid data', async () => {
    const photoData = {
      url: 'https://picsum.photos/400/300.png',
      description: 'New photo'
    };
    const res = await request(app).post('/api/gallery').send(photoData);
    expect(res.status).toBe(201);
    expect(res.body.url).toBe(photoData.url);
    expect(res.body.description).toBe(photoData.description);
  });

  it('should return 400 with invalid URL', async () => {
    const invalidData = { url: 'not-a-url', description: 'Invalid' };
    const res = await request(app).post('/api/gallery').send(invalidData);
    expect(res.status).toBe(400);
    expect(res.body.error).toBeDefined();
  });
});
