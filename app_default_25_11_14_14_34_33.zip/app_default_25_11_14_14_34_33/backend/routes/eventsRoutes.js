import express from 'express';
import Event from '../models/Event.js';

const router = express.Router();

// GET upcoming events sorted by date ascending
router.get('/', async (req, res, next) => {
  try {
    const now = new Date();
    const events = await Event.find({ date: { $gte: now } })
      .sort({ date: 1 })
      .exec();
    return res.json(events);
  } catch (error) {
    next(error);
  }
});

// POST add new event
router.post('/', async (req, res, next) => {
  try {
    const { title, description, date, location } = req.body;

    if (
      typeof title !== 'string' ||
      title.trim() === '' ||
      title.length > 200 ||
      (description && (typeof description !== 'string' || description.length > 2000)) ||
      !date ||
      isNaN(Date.parse(date)) ||
      (location && (typeof location !== 'string' || location.length > 300))
    ) {
      return res.status(400).json({ error: 'Invalid event data' });
    }

    const eventDate = new Date(date);
    if (eventDate < new Date()) {
      return res.status(400).json({ error: 'Event date must be in the future' });
    }

    const event = new Event({
      title: title.trim(),
      description: description ? description.trim() : '',
      date: eventDate,
      location: location ? location.trim() : ''
    });

    await event.save();

    return res.status(201).json(event);
  } catch (error) {
    next(error);
  }
});

export default router;
