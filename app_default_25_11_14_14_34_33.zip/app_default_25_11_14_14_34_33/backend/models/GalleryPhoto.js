import mongoose from 'mongoose';

const galleryPhotoSchema = new mongoose.Schema(
  {
    url: {
      type: String,
      required: true,
      trim: true,
      validate: {
        validator: (v) =>
          /^https?:\/\/.+\.(jpg|jpeg|png|gif|bmp|webp|svg)$/i.test(v),
        message: 'URL must be a valid image URL (jpg, png, gif, bmp, webp, svg)'
      }
    },
    description: {
      type: String,
      trim: true,
      maxlength: 500
    },
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  },
  { versionKey: false }
);

const GalleryPhoto = mongoose.model('GalleryPhoto', galleryPhotoSchema);

export default GalleryPhoto;
