import request from 'supertest';
import mongoose from 'mongoose';
import express from 'express';
import eventsRoutes from '../../backend/routes/eventsRoutes.js';
import Event from '../../backend/models/Event.js';

const app = express();
app.use(express.json());
app.use('/api/events', eventsRoutes);

beforeAll(async () => {
  const mongoUri = 'mongodb://127.0.0.1/familywebsite_test_events';
  await mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });
  await Event.deleteMany({});
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('GET /api/events', () => {
  it('should return empty array when no upcoming events', async () => {
    const res = await request(app).get('/api/events');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBe(0);
  });

  it('should return upcoming events ordered by date', async () => {
    const now = new Date();
    const event1 = new Event({
      title: 'First Event',
      date: new Date(now.getTime() + 86400000),
      description: 'Desc 1',
      location: 'Location 1'
    });
    const event2 = new Event({
      title: 'Second Event',
      date: new Date(now.getTime() + 172800000),
      description: 'Desc 2',
      location: 'Location 2'
    });
    await event1.save();
    await event2.save();

    const res = await request(app).get('/api/events');
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThanOrEqual(2);
    expect(new Date(res.body[0].date) <= new Date(res.body[1].date)).toBe(true);
  });
});

describe('POST /api/events', () => {
  it('should add valid new event', async () => {
    const futureDate = new Date(Date.now() + 86400000).toISOString();
    const eventData = {
      title: 'Test Event',
      description: 'Test desc',
      date: futureDate,
      location: 'Test location'
    };
    const res = await request(app).post('/api/events').send(eventData);
    expect(res.status).toBe(201);
    expect(res.body.title).toBe(eventData.title);
  });

  it('should reject event with past date', async () => {
    const pastDate = new Date(Date.now() - 86400000).toISOString();
    const eventData = {
      title: 'Past Event',
      date: pastDate,
      description: 'Desc',
      location: 'Loc'
    };
    const res = await request(app).post('/api/events').send(eventData);
    expect(res.status).toBe(400);
    expect(res.body.error).toBeDefined();
  });

  it('should reject invalid input', async () => {
    const eventData = {
      title: '',
      date: 'invalid-date'
    };
    const res = await request(app).post('/api/events').send(eventData);
    expect(res.status).toBe(400);
    expect(res.body.error).toBeDefined();
  });
});
