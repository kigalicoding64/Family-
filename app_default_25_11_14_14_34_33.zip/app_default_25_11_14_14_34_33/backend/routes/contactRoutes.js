import express from 'express';
import ContactMessage from '../models/ContactMessage.js';

const router = express.Router();

// POST contact form message
router.post('/', async (req, res, next) => {
  try {
    const { name, email, message } = req.body;

    if (
      typeof name !== 'string' ||
      name.trim() === '' ||
      name.length > 100 ||
      typeof email !== 'string' ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) ||
      email.length > 320 ||
      typeof message !== 'string' ||
      message.trim() === '' ||
      message.length > 5000
    ) {
      return res.status(400).json({ error: 'Invalid contact form data' });
    }

    const contactMessage = new ContactMessage({
      name: name.trim(),
      email: email.trim(),
      message: message.trim()
    });

    await contactMessage.save();

    return res.status(201).json({ message: 'Message sent successfully' });
  } catch (error) {
    next(error);
  }
});

export default router;
