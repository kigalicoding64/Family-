# Dynamic Family Website

Welcome to the Dynamic Family Website project! This application provides a beautiful and responsive platform for families to share their story, photos, upcoming events, and connect via a contact form. It also includes a smart AI assistant widget to engage visitors interactively.

---

## Features

- Home page displaying family introduction and story
- Gallery page showcasing family photos in a responsive grid
- Events page listing upcoming family events with details
- Contact page with a secure message form
- AI assistant widget fixed at bottom-left with conversational UI
- Fully responsive design for all screen sizes
- REST API backend with Node.js, Express, MongoDB
- React frontend with React Router and Axios for data fetching
- Comprehensive error handling and input validation
- Dockerfiles for easy containerized deployment
- Automated tests for backend and frontend components

---

## Prerequisites

Before you begin, ensure you have met the following requirements:

- **Node.js** v18 or higher installed
- **npm** v9 or higher installed (comes with Node.js)
- **MongoDB** instance available (local or cloud, e.g., MongoDB Atlas)
- For Docker usage: Docker installed and running

---

## Installation

1. **Clone the repository**

