import express from 'express';
import GalleryPhoto from '../models/GalleryPhoto.js';

const router = express.Router();

// GET all gallery photos
router.get('/', async (req, res, next) => {
  try {
    const photos = await GalleryPhoto.find().sort({ uploadedAt: -1 }).exec();
    return res.json(photos);
  } catch (error) {
    next(error);
  }
});

// POST add new gallery photo
router.post('/', async (req, res, next) => {
  try {
    const { url, description } = req.body;

    if (
      typeof url !== 'string' ||
      !/^https?:\/\/.+\.(jpg|jpeg|png|gif|bmp|webp|svg)$/i.test(url.trim()) ||
      url.trim().length > 2048
    ) {
      return res.status(400).json({ error: 'Invalid photo URL' });
    }

    if (description && (typeof description !== 'string' || description.trim().length > 500)) {
      return res.status(400).json({ error: 'Invalid photo description' });
    }

    const photo = new GalleryPhoto({
      url: url.trim(),
      description: description ? description.trim() : ''
    });

    await photo.save();

    return res.status(201).json(photo);
  } catch (error) {
    next(error);
  }
});

export default router;
