import mongoose from 'mongoose';

const familyInfoSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100
    },
    description: {
      type: String,
      required: true,
      trim: true,
      maxlength: 5000
    },
    updatedAt: {
      type: Date,
      default: Date.now
    }
  },
  { versionKey: false }
);

familyInfoSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

const FamilyInfo = mongoose.model('FamilyInfo', familyInfoSchema);

export default FamilyInfo;
