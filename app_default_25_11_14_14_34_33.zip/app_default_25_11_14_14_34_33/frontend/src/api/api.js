import axios from 'axios';

const baseURL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api';

const apiClient = axios.create({
  baseURL,
  timeout: 8000,
  headers: {
    'Content-Type': 'application/json'
  }
});

export async function fetchFamilyInfo() {
  const response = await apiClient.get('/family');
  return response.data;
}

export async function fetchGalleryPhotos() {
  const response = await apiClient.get('/gallery');
  return response.data;
}

export async function fetchEvents() {
  const response = await apiClient.get('/events');
  return response.data;
}

export async function postContactMessage(messageData) {
  const response = await apiClient.post('/contact', messageData);
  return response.data;
}
