import request from 'supertest';
import mongoose from 'mongoose';
import express from 'express';
import contactRoutes from '../../backend/routes/contactRoutes.js';
import ContactMessage from '../../backend/models/ContactMessage.js';

const app = express();
app.use(express.json());
app.use('/api/contact', contactRoutes);

beforeAll(async () => {
  const mongoUri = 'mongodb://127.0.0.1/familywebsite_test_contact';
  await mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });
  await ContactMessage.deleteMany({});
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('POST /api/contact', () => {
  it('should save valid contact message', async () => {
    const messageData = {
      name: 'John Doe',
      email: 'john.doe@example.com',
      message: 'Hello, this is a test message.'
    };

    const res = await request(app).post('/api/contact').send(messageData);
    expect(res.status).toBe(201);
    expect(res.body.message).toBe('Message sent successfully');

    const saved = await ContactMessage.findOne({ email: 'john.doe@example.com' }).exec();
    expect(saved).not.toBeNull();
    expect(saved.name).toBe(messageData.name);
  });

  it('should reject invalid email', async () => {
    const messageData = {
      name: 'Jane Doe',
      email: 'invalid-email',
      message: 'Test'
    };

    const res = await request(app).post('/api/contact').send(messageData);
    expect(res.status).toBe(400);
    expect(res.body.error).toBeDefined();
  });

  it('should reject empty message', async () => {
    const messageData = {
      name: 'Jane Doe',
      email: 'jane@example.com',
      message: ''
    };

    const res = await request(app).post('/api/contact').send(messageData);
    expect(res.status).toBe(400);
    expect(res.body.error).toBeDefined();
  });
});
