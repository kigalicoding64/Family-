import React, { useEffect, useState } from 'react';
import { fetchGalleryPhotos } from '../api/api.js';

const Gallery = () => {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadPhotos = async () => {
      try {
        const data = await fetchGalleryPhotos();
        setPhotos(data);
      } catch (err) {
        setError('Failed to load gallery photos.');
      } finally {
        setLoading(false);
      }
    };
    loadPhotos();
  }, []);

  if (loading) {
    return <p>Loading gallery photos...</p>;
  }

  if (error) {
    return <p role="alert" style={{ color: 'red' }}>{error}</p>;
  }

  if (photos.length === 0) {
    return <p>No photos available in the gallery.</p>;
  }

  return (
    <section
      aria-label="Family photo gallery"
      style={{ maxWidth: '900px', margin: '0 auto', padding: '1rem' }}
    >
      <h2 style={{ fontSize: '1.8rem', color: '#34495e', marginBottom: '1rem' }}>
        Family Gallery
      </h2>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
          gap: '1rem'
        }}
      >
        {photos.map((photo) => (
          <figure key={photo._id} style={{ margin: 0 }}>
            <img
              src={photo.url}
              alt={photo.description || 'Family photo'}
              loading="lazy"
              style={{ width: '100%', borderRadius: '8px', objectFit: 'cover', aspectRatio: '4 / 3' }}
            />
            {photo.description && (
              <figcaption
                style={{ fontSize: '0.85rem', color: '#666', marginTop: '0.3rem' }}
              >
                {photo.description}
              </figcaption>
            )}
          </figure>
        ))}
      </div>
    </section>
  );
};

export default Gallery;
