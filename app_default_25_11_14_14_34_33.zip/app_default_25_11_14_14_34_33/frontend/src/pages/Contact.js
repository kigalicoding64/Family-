import React, { useState } from 'react';
import { postContactMessage } from '../api/api.js';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState({ type: '', message: '' });
  const [submitting, setSubmitting] = useState(false);

  const validateEmail = (email) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

  const handleChange = (e) => {
    setFormData((data) => ({ ...data, [e.target.name]: e.target.value }));
    setStatus({ type: '', message: '' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const { name, email, message } = formData;

    if (!name.trim() || name.trim().length > 100) {
      setStatus({ type: 'error', message: 'Please enter a valid name (max 100 characters).' });
      return;
    }

    if (!validateEmail(email)) {
      setStatus({ type: 'error', message: 'Please enter a valid email address.' });
      return;
    }

    if (!message.trim() || message.trim().length > 5000) {
      setStatus({ type: 'error', message: 'Please enter a message (max 5000 characters).' });
      return;
    }

    setSubmitting(true);
    setStatus({ type: '', message: '' });

    try {
      await postContactMessage({ name: name.trim(), email: email.trim(), message: message.trim() });
      setStatus({ type: 'success', message: 'Your message has been sent successfully!' });
      setFormData({ name: '', email: '', message: '' });
    } catch (err) {
      setStatus({ type: 'error', message: 'Failed to send message. Please try again later.' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section
      aria-labelledby="contact-form-title"
      style={{ maxWidth: '600px', margin: '0 auto', padding: '1rem' }}
    >
      <h2 id="contact-form-title" style={{ color: '#34495e', marginBottom: '1rem' }}>
        Contact Us
      </h2>
      <form onSubmit={handleSubmit} noValidate>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="name" style={{ display: 'block', marginBottom: '0.2rem' }}>
            Name<span aria-hidden="true" style={{ color: 'red' }}> *</span>
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            maxLength={100}
            required
            disabled={submitting}
            aria-required="true"
            style={{
              width: '100%',
              padding: '0.5rem',
              fontSize: '1rem',
              borderRadius: 4,
              border: '1px solid #ccc',
              boxSizing: 'border-box'
            }}
          />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="email" style={{ display: 'block', marginBottom: '0.2rem' }}>
            Email<span aria-hidden="true" style={{ color: 'red' }}> *</span>
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            maxLength={320}
            required
            disabled={submitting}
            aria-required="true"
            style={{
              width: '100%',
              padding: '0.5rem',
              fontSize: '1rem',
              borderRadius: 4,
              border: '1px solid #ccc',
              boxSizing: 'border-box'
            }}
          />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="message" style={{ display: 'block', marginBottom: '0.2rem' }}>
            Message<span aria-hidden="true" style={{ color: 'red' }}> *</span>
          </label>
          <textarea
            id="message"
            name="message"
            rows={5}
            value={formData.message}
            onChange={handleChange}
            maxLength={5000}
            required
            disabled={submitting}
            aria-required="true"
            style={{
              width: '100%',
              padding: '0.5rem',
              fontSize: '1rem',
              borderRadius: 4,
              border: '1px solid #ccc',
              boxSizing: 'border-box',
              resize: 'vertical'
            }}
          />
        </div>
        {status.message && (
          <p
            role={status.type === 'error' ? 'alert' : undefined}
            style={{ color: status.type === 'error' ? 'red' : 'green', marginBottom: '1rem' }}
          >
            {status.message}
          </p>
        )}
        <button
          type="submit"
          disabled={submitting}
          style={{
            backgroundColor: '#2980b9',
            color: 'white',
            fontWeight: 'bold',
            border: 'none',
            padding: '0.75rem 1.5rem',
            fontSize: '1rem',
            borderRadius: 6,
            cursor: submitting ? 'not-allowed' : 'pointer'
          }}
        >
          {submitting ? 'Sending...' : 'Send Message'}
        </button>
      </form>
    </section>
  );
};

export default Contact;
