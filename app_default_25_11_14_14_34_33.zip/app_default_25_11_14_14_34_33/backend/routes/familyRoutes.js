import express from 'express';
import FamilyInfo from '../models/FamilyInfo.js';

const router = express.Router();

// GET current family introduction
router.get('/', async (req, res, next) => {
  try {
    let familyInfo = await FamilyInfo.findOne().exec();
    if (!familyInfo) {
      // Return default empty object if none found
      return res.json({ name: '', description: '' });
    }
    return res.json(familyInfo);
  } catch (error) {
    next(error);
  }
});

// PUT update family introduction
router.put('/', async (req, res, next) => {
  try {
    const { name, description } = req.body;

    if (
      typeof name !== 'string' ||
      name.trim() === '' ||
      name.length > 100 ||
      typeof description !== 'string' ||
      description.trim() === '' ||
      description.length > 5000
    ) {
      return res.status(400).json({ error: 'Invalid name or description' });
    }

    let familyInfo = await FamilyInfo.findOne().exec();

    if (!familyInfo) {
      familyInfo = new FamilyInfo({ name: name.trim(), description: description.trim() });
    } else {
      familyInfo.name = name.trim();
      familyInfo.description = description.trim();
    }

    await familyInfo.save();
    return res.json(familyInfo);
  } catch (error) {
    next(error);
  }
});

export default router;
