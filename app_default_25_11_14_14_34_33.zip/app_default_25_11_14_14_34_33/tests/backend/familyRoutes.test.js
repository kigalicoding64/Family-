import request from 'supertest';
import mongoose from 'mongoose';
import express from 'express';
import familyRoutes from '../../backend/routes/familyRoutes.js';
import FamilyInfo from '../../backend/models/FamilyInfo.js';

const app = express();
app.use(express.json());
app.use('/api/family', familyRoutes);

beforeAll(async () => {
  const mongoUri = 'mongodb://127.0.0.1/familywebsite_test_family';
  await mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });
  await FamilyInfo.deleteMany({});
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('GET /api/family', () => {
  it('should return empty family info if none exists', async () => {
    const res = await request(app).get('/api/family');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ name: '', description: '' });
  });

  it('should return existing family info', async () => {
    const familyData = { name: 'Smith Family', description: 'We love reunions.' };
    const familyInfo = new FamilyInfo(familyData);
    await familyInfo.save();

    const res = await request(app).get('/api/family');
    expect(res.status).toBe(200);
    expect(res.body.name).toBe(familyData.name);
    expect(res.body.description).toBe(familyData.description);
  });
});

describe('PUT /api/family', () => {
  it('should update family info', async () => {
    const newData = { name: 'Johnson Family', description: 'Updated description here.' };
    const res = await request(app).put('/api/family').send(newData);
    expect(res.status).toBe(200);
    expect(res.body.name).toBe(newData.name);
    expect(res.body.description).toBe(newData.description);
  });

  it('should return 400 on invalid input', async () => {
    const invalidData = { name: '', description: '' };
    const res = await request(app).put('/api/family').send(invalidData);
    expect(res.status).toBe(400);
    expect(res.body.error).toBeDefined();
  });
});
