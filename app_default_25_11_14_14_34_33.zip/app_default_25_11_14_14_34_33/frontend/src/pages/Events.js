import React, { useEffect, useState } from 'react';
import { fetchEvents } from '../api/api.js';

const formatDate = (dateString) => {
  try {
    return new Date(dateString).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  } catch {
    return dateString;
  }
};

const Events = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadEvents = async () => {
      try {
        const data = await fetchEvents();
        setEvents(data);
      } catch (err) {
        setError('Failed to load events.');
      } finally {
        setLoading(false);
      }
    };
    loadEvents();
  }, []);

  if (loading) {
    return <p>Loading events...</p>;
  }

  if (error) {
    return <p role="alert" style={{ color: 'red' }}>{error}</p>;
  }

  if (events.length === 0) {
    return <p>No upcoming events found.</p>;
  }

  return (
    <section
      aria-label="Upcoming family events"
      style={{ maxWidth: '800px', margin: '0 auto', padding: '1rem' }}
    >
      <h2 style={{ fontSize: '1.8rem', color: '#34495e', marginBottom: '1rem' }}>
        Upcoming Events
      </h2>
      <ul style={{ listStyleType: 'none', padding: 0 }}>
        {events.map(({ _id, title, date, location, description }) => (
          <li
            key={_id}
            style={{
              marginBottom: '1.5rem',
              paddingBottom: '1rem',
              borderBottom: '1px solid #ccc'
            }}
          >
            <h3 style={{ margin: 0, color: '#2c3e50' }}>{title}</h3>
            <p style={{ margin: '0.3rem 0', color: '#7f8c8d' }}>
              <time dateTime={date}>{formatDate(date)}</time>
              {location ? ` | ${location}` : ''}
            </p>
            {description && (
              <p style={{ marginTop: '0.5rem', color: '#555' }}>{description}</p>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
};

export default Events;
