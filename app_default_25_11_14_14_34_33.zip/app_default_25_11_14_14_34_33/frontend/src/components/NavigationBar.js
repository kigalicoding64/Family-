import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const activeStyle = {
  fontWeight: 'bold',
  color: '#2c3e50',
  borderBottom: '2px solid #2980b9'
};

const NavigationBar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => setMenuOpen((open) => !open);

  const closeMenu = () => setMenuOpen(false);

  return (
    <nav
      style={{
        backgroundColor: '#3498db',
        padding: '0.5rem 1rem',
        position: 'sticky',
        top: 0,
        zIndex: 1000
      }}
      aria-label="Primary Navigation"
    >
      <div
        style={{
          maxWidth: '900px',
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}
      >
        <div style={{ color: 'white', fontWeight: 'bold', fontSize: '1.5rem' }}>
          Family Website
        </div>
        <button
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle menu"
          style={{
            background: 'none',
            border: 'none',
            color: 'white',
            fontSize: '1.5rem',
            cursor: 'pointer',
            display: 'none'
          }}
          id="menu-toggle"
        >
          &#9776;
        </button>
        <ul
          id="primary-navigation"
          style={{
            listStyle: 'none',
            display: 'flex',
            margin: 0,
            padding: 0,
            gap: '1.5rem'
          }}
          className={menuOpen ? 'open' : ''}
        >
          <li>
            <NavLink
              to="/"
              style={({ isActive }) => (isActive ? activeStyle : { color: 'white', textDecoration: 'none' })}
              onClick={closeMenu}
              end
            >
              Home
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/gallery"
              style={({ isActive }) => (isActive ? activeStyle : { color: 'white', textDecoration: 'none' })}
              onClick={closeMenu}
            >
              Gallery
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/events"
              style={({ isActive }) => (isActive ? activeStyle : { color: 'white', textDecoration: 'none' })}
              onClick={closeMenu}
            >
              Events
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/contact"
              style={({ isActive }) => (isActive ? activeStyle : { color: 'white', textDecoration: 'none' })}
              onClick={closeMenu}
            >
              Contact
            </NavLink>
          </li>
        </ul>
      </div>
      <style>{`
        @media (max-width: 600px) {
          nav > div > button#menu-toggle {
            display: block;
          }
          nav > div > ul {
            flex-direction: column;
            display: none;
            background-color: #2980b9;
            position: absolute;
            top: 100%;
            right: 0;
            width: 180px;
            border-radius: 0 0 5px 5px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            z-index: 1000;
          }
          nav > div > ul.open {
            display: flex;
          }
          nav > div > ul li {
            margin: 0.5rem 0;
          }
          nav > div > ul li a {
            padding: 0.5rem 1rem;
            display: block;
          }
        }
      `}</style>
    </nav>
  );
};

export default NavigationBar;
