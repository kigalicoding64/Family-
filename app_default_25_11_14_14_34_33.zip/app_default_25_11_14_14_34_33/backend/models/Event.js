import mongoose from 'mongoose';

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
      maxlength: 200
    },
    description: {
      type: String,
      trim: true,
      maxlength: 2000
    },
    date: {
      type: Date,
      required: true,
      validate: {
        validator: (v) => v instanceof Date && !isNaN(v),
        message: 'Date must be a valid date'
      }
    },
    location: {
      type: String,
      trim: true,
      maxlength: 300
    }
  },
  { versionKey: false }
);

const Event = mongoose.model('Event', eventSchema);

export default Event;
